# The Cube

A Pen created on CodePen.

Original URL: [https://codepen.io/style-zone-24/pen/raeLqZV](https://codepen.io/style-zone-24/pen/raeLqZV).

See if you can solve this classic Rubik's puzzle game made in three.js.